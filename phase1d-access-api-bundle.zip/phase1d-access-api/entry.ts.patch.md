# entry.ts — apply these two insertions (do NOT replace the whole file)

main's `src/server/entry.ts` has routes this branch copy lacks, so apply the
additions at the anchors below rather than overwriting the file.

## 1. Add imports — right AFTER this existing line:
```
import admin_users_id_security_events_get_193 from "./api/admin/users/[id]/security-events/GET";
```
Insert:
```ts
import admin_access_roles_get from "./api/admin/access/roles/GET";
import admin_access_admins_get from "./api/admin/access/admins/GET";
import admin_access_admins_post from "./api/admin/access/admins/POST";
import admin_access_admins_id_roles_post from "./api/admin/access/admins/[id]/roles/POST";
```

## 2. Add route registrations — right AFTER this existing line:
```
app.get("/api/admin/users/:id/security-events", admin_users_id_security_events_get_193);
```
Insert:
```ts
// Admin access management (RBAC) — reserved to SUPER_ADMIN via central authorization (`access` → SUPER_ONLY)
app.get("/api/admin/access/roles", admin_access_roles_get);
app.get("/api/admin/access/admins", admin_access_admins_get);
app.post("/api/admin/access/admins", admin_access_admins_post);
app.post("/api/admin/access/admins/:id/roles", admin_access_admins_id_roles_post);
```
If the anchor lines differ on main, place the imports with the other admin
handler imports and the registrations with the other `/api/admin/...` routes —
they only need to sit after the auth/authorization/csrf/audit `app.use('/api/admin', ...)` chain, which they do by construction.
