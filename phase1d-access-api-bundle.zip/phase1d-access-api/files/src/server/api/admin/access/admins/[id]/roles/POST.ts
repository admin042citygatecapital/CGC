/**
 * POST /api/admin/access/admins/:id/roles
 *
 * Replaces a managed administrator's role assignments (idempotent set-semantics)
 * and records a before/after audit summary. Reserved to SUPER_ADMIN by the
 * central authorization policy (`access` → SUPER_ONLY).
 *
 * Body: { roles: string[], reason }
 */
import type { Request, Response } from 'express';
import { getAdminRoles, setAdminRoles } from '../../../../../../lib/adminIdentityStore.js';
import { sanitizeString, safeObject } from '../../../../../../lib/inputValidator.js';
import { appendAuditEntry } from '../../../../../../lib/auditLog.js';

export default async function handler(req: Request, res: Response) {
  const session = req.adminSession;
  if (!session) return res.status(401).json({ error: 'Authentication required' });

  const id = String(req.params.id ?? '').trim();
  if (!id) return res.status(400).json({ error: 'Administrator ID required' });

  const body = safeObject(req.body) ?? {};
  const reason = sanitizeString(body.reason, 500);
  const roles = Array.isArray(body.roles) ? body.roles.map((r) => String(r)) : null;

  if (roles === null) return res.status(400).json({ error: 'A roles array is required.' });
  if (!reason) return res.status(400).json({ error: 'A reason is required for this administration action.' });

  try {
    const before = await getAdminRoles(id);
    const after = await setAdminRoles(id, roles, session.adminId);
    await appendAuditEntry({
      adminId: session.adminId,
      adminEmail: session.email,
      action: 'admin_user_roles_set',
      module: 'access',
      resource: 'admin_user',
      resourceId: id,
      role: session.role,
      permission: 'ROLES_MANAGE',
      reason,
      result: 'success',
      beforeSummary: { roles: before },
      afterSummary: { roles: after },
    }).catch((auditError) => {
      console.error('[access] structured audit failed for admin_user_roles_set', {
        errorType: auditError instanceof Error ? auditError.name : 'UnknownError',
      });
    });
    return res.json({ id, roles: after });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes('requires a configured database')) {
      return res.status(503).json({ error: 'Managed administrator storage is not configured.' });
    }
    if (/foreign key|violates|not present/i.test(message)) {
      return res.status(404).json({ error: 'Unknown administrator.' });
    }
    console.error('[access] set roles failed', { errorType: error instanceof Error ? error.name : 'UnknownError' });
    return res.status(500).json({ error: 'Failed to update administrator roles.' });
  }
}
