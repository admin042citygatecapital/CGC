/**
 * GET /api/admin/access/roles
 *
 * Returns the RBAC catalogue: every role with its granted permissions, and the
 * flat permission list. Read-only reference data for the access-management UI.
 * Reserved to SUPER_ADMIN by the central authorization policy (`access` prefix
 * → SUPER_ONLY in adminRbac.ts).
 */
import type { Request, Response } from 'express';
import { roleCatalogue } from '../../../../lib/adminRbac.js';

export default async function handler(_req: Request, res: Response) {
  return res.json(roleCatalogue());
}
