/**
 * GET /api/admin/access/admins
 *
 * Lists managed administrators and the roles they hold. Reserved to SUPER_ADMIN
 * by the central authorization policy (`access` → SUPER_ONLY).
 */
import type { Request, Response } from 'express';
import { listAdminUsers } from '../../../../lib/adminIdentityStore.js';

export default async function handler(_req: Request, res: Response) {
  try {
    const admins = await listAdminUsers();
    return res.json({ admins });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes('requires a configured database')) {
      return res.status(503).json({ error: 'Managed administrator storage is not configured.' });
    }
    console.error('[access] list admins failed', { errorType: error instanceof Error ? error.name : 'UnknownError' });
    return res.status(500).json({ error: 'Failed to list administrators.' });
  }
}
