/**
 * POST /api/admin/access/admins
 *
 * Creates a managed administrator and (optionally) assigns roles. Managed
 * administrators are created WITHOUT sign-in credentials in this increment;
 * enabling their login is a separate, reviewed auth-path change. Reserved to
 * SUPER_ADMIN by the central authorization policy (`access` → SUPER_ONLY).
 *
 * Body: { email, name, roles?: string[], reason }
 */
import type { Request, Response } from 'express';
import { createAdminUser } from '../../../../lib/adminIdentityStore.js';
import { sanitizeString, isValidEmail, safeObject } from '../../../../lib/inputValidator.js';
import { appendAuditEntry } from '../../../../lib/auditLog.js';

export default async function handler(req: Request, res: Response) {
  const session = req.adminSession;
  if (!session) return res.status(401).json({ error: 'Authentication required' });

  const body = safeObject(req.body) ?? {};
  const email = sanitizeString(body.email, 254).toLowerCase();
  const name = sanitizeString(body.name, 120);
  const reason = sanitizeString(body.reason, 500);
  const roles = Array.isArray(body.roles) ? body.roles.map((r) => String(r)) : [];

  if (!name) return res.status(400).json({ error: 'Name is required.' });
  if (!isValidEmail(email)) return res.status(400).json({ error: 'A valid email address is required.' });
  if (!reason) return res.status(400).json({ error: 'A reason is required for this administration action.' });

  try {
    const created = await createAdminUser({ email, name, roles, createdBy: session.adminId });
    // Structured audit (blanket mutation audit also records this request).
    await appendAuditEntry({
      adminId: session.adminId,
      adminEmail: session.email,
      action: 'admin_user_created',
      module: 'access',
      resource: 'admin_user',
      resourceId: created.id,
      role: session.role,
      permission: 'ADMIN_USERS_MANAGE',
      reason,
      result: 'success',
      afterSummary: { email: created.email, name: created.name, roles: created.roles, status: created.status },
    }).catch((auditError) => {
      console.error('[access] structured audit failed for admin_user_created', {
        errorType: auditError instanceof Error ? auditError.name : 'UnknownError',
      });
    });
    return res.status(201).json({ admin: created });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes('requires a configured database')) {
      return res.status(503).json({ error: 'Managed administrator storage is not configured.' });
    }
    if (/duplicate|unique/i.test(message)) {
      return res.status(409).json({ error: 'An administrator with this email already exists.' });
    }
    console.error('[access] create admin failed', { errorType: error instanceof Error ? error.name : 'UnknownError' });
    return res.status(500).json({ error: 'Failed to create administrator.' });
  }
}
