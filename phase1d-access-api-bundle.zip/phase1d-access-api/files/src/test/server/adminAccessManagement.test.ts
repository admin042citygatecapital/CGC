import { describe, expect, it, vi } from 'vitest';
import type { Request, Response } from 'express';
import { requiredAccessForAdminRequest } from '../../server/lib/adminAuthorizationMiddleware.js';
import rolesGet from '../../server/api/admin/access/roles/GET.js';
import adminsGet from '../../server/api/admin/access/admins/GET.js';
import adminsPost from '../../server/api/admin/access/admins/POST.js';

function res() {
  const json = vi.fn();
  const status = vi.fn(() => ({ json }));
  return { res: { status, json } as unknown as Response, status, json };
}

const superSession = {
  adminId: 'admin_001', email: 'admin@citygate.capital', role: 'SUPER_ADMIN' as const,
  createdAt: '', lastSeenAt: '', ip: '127.0.0.1', ua: 'test',
};

describe('admin access management API', () => {
  it('reserves every /access route to SUPER_ADMIN', () => {
    expect(requiredAccessForAdminRequest('/access/roles', 'GET')).toBe('SUPER_ONLY');
    expect(requiredAccessForAdminRequest('/access/admins', 'GET')).toBe('SUPER_ONLY');
    expect(requiredAccessForAdminRequest('/access/admins', 'POST')).toBe('SUPER_ONLY');
    expect(requiredAccessForAdminRequest('/access/admins/au_1/roles', 'POST')).toBe('SUPER_ONLY');
  });

  it('returns the full RBAC catalogue', async () => {
    const { res: r, json } = res();
    await rolesGet({} as Request, r);
    const payload = json.mock.calls[0][0];
    expect(payload.roles).toHaveLength(8);
    const superRole = payload.roles.find((x: { role: string }) => x.role === 'SUPER_ADMIN');
    expect(superRole.permissions).toContain('ADMIN_USERS_MANAGE');
    expect(superRole.permissions).toContain('ROLES_MANAGE');
    expect(payload.permissions).toContain('TRANSFERS_APPROVE');
  });

  it('validates create-admin input before any storage access', async () => {
    // Missing reason
    {
      const { res: r, status } = res();
      await adminsPost({ adminSession: superSession, body: { email: 'a@b.com', name: 'A' } } as unknown as Request, r);
      expect(status).toHaveBeenCalledWith(400);
    }
    // Invalid email
    {
      const { res: r, status } = res();
      await adminsPost({ adminSession: superSession, body: { email: 'not-an-email', name: 'A', reason: 'x' } } as unknown as Request, r);
      expect(status).toHaveBeenCalledWith(400);
    }
  });

  it('fails safe when managed-admin storage is not configured', async () => {
    // No DATABASE_URL in the test environment → the store refuses.
    const { res: r, status } = res();
    await adminsGet({} as Request, r);
    expect(status).toHaveBeenCalledWith(503);
  });
});
