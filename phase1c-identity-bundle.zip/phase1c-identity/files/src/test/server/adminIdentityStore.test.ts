import { describe, expect, it } from 'vitest';
import type { Permission } from '../../server/lib/adminRbac.js';
import {
  PermissionCache,
  computeEffectivePermissions,
  normalizeRoleAssignments,
} from '../../server/lib/adminIdentityStore.js';

describe('admin identity — role assignment normalisation', () => {
  it('keeps only recognised roles, de-duplicated and order-stable', () => {
    expect(normalizeRoleAssignments(['SUPPORT_ADMIN', 'FINANCE_ADMIN', 'SUPPORT_ADMIN']))
      .toEqual(['FINANCE_ADMIN', 'SUPPORT_ADMIN']); // canonical ADMIN_ROLES order
    expect(normalizeRoleAssignments(['NONSENSE', 'AUDITOR', ''])).toEqual(['AUDITOR']);
    expect(normalizeRoleAssignments([])).toEqual([]);
  });
});

describe('admin identity — effective permissions', () => {
  it('unions permissions across roles', () => {
    const finance = computeEffectivePermissions(['FINANCE_ADMIN']);
    const compliance = computeEffectivePermissions(['COMPLIANCE_ADMIN']);
    const both = computeEffectivePermissions(['FINANCE_ADMIN', 'COMPLIANCE_ADMIN']);
    expect(both.has('TRANSFERS_MANAGE')).toBe(true);   // from finance
    expect(both.has('KYC_MANAGE')).toBe(true);         // from compliance
    expect(both.size).toBeGreaterThanOrEqual(Math.max(finance.size, compliance.size));
  });

  it('grants SUPER_ADMIN the full catalogue', () => {
    const perms = computeEffectivePermissions(['SUPER_ADMIN']);
    expect(perms.has('ADMIN_USERS_MANAGE')).toBe(true);
    expect(perms.has('ROLES_MANAGE')).toBe(true);
    expect(perms.has('SYSTEM_MANAGE')).toBe(true);
  });

  it('never grants AUDITOR any *_MANAGE permission', () => {
    const perms = computeEffectivePermissions(['AUDITOR']);
    for (const p of perms) expect(p.endsWith('_MANAGE') || p.endsWith('_APPROVE')).toBe(false);
  });
});

describe('admin identity — permission cache', () => {
  it('caches within TTL and reloads after expiry', async () => {
    let now = 1_000;
    let loads = 0;
    const cache = new PermissionCache(100, () => now);
    const loader = async (): Promise<ReadonlySet<Permission>> => {
      loads += 1;
      return new Set<Permission>(['USERS_READ']);
    };
    await cache.resolve('a', loader);
    await cache.resolve('a', loader);
    expect(loads).toBe(1);            // second call served from cache
    now += 150;                       // past TTL
    await cache.resolve('a', loader);
    expect(loads).toBe(2);            // reloaded
  });

  it('invalidate forces a reload', async () => {
    let loads = 0;
    const cache = new PermissionCache(10_000);
    const loader = async (): Promise<ReadonlySet<Permission>> => {
      loads += 1;
      return new Set<Permission>(['USERS_READ']);
    };
    await cache.resolve('x', loader);
    cache.invalidate('x');
    await cache.resolve('x', loader);
    expect(loads).toBe(2);
  });
});
