-- 0049_admin_identity.sql
-- Phase 1 (RBAC foundation): managed administrator identities and their role
-- assignments. The role -> permission matrix stays code-authoritative in
-- adminRbac.ts; these tables only record WHO exists and WHICH ROLES they hold.
-- The env-bootstrap SUPER_ADMIN remains the break-glass account and is not
-- stored here.
--
-- Additive and idempotent. RLS is enabled with no policy (deny-by-default),
-- matching the platform posture: privileged access is server-side via the
-- service role; RLS never substitutes for the server-side RBAC checks.
--
-- NOTE: renumber to follow main's latest migration before committing.

CREATE TABLE IF NOT EXISTS admin_users (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL,
  name          TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','disabled')),
  password_hash TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by    TEXT,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_login_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS admin_users_email_idx ON admin_users(LOWER(email));
CREATE INDEX IF NOT EXISTS admin_users_status_idx ON admin_users(status);

CREATE TABLE IF NOT EXISTS admin_user_roles (
  id            TEXT PRIMARY KEY,
  admin_user_id TEXT NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
  role          admin_role NOT NULL,
  granted_by    TEXT,
  granted_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS admin_user_roles_unique_idx ON admin_user_roles(admin_user_id, role);
CREATE INDEX IF NOT EXISTS admin_user_roles_admin_idx ON admin_user_roles(admin_user_id);

ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_user_roles ENABLE ROW LEVEL SECURITY;
