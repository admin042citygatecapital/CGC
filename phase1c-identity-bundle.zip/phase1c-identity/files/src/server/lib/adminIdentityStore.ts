/**
 * adminIdentityStore.ts — managed administrator identities and role assignments.
 *
 * The env-bootstrap SUPER_ADMIN (adminCredentials.ts) remains the break-glass
 * account and is NOT stored here. This store manages *additional* administrators
 * and the roles they hold. The role -> permission mapping is not duplicated: it
 * stays code-authoritative in adminRbac.ts and is resolved via
 * computeEffectivePermissions().
 *
 * Privileged: all mutations here are SUPER_ADMIN-only at the API layer.
 */

import crypto from 'node:crypto';
import { eq } from 'drizzle-orm';
import { getDb, isDatabaseConfigured } from '../db/db.js';
import { adminUsers, adminUserRoles } from '../db/schema.js';
import type { AdminRole } from './sessionStore.js';
import { ADMIN_ROLES, permissionsForRoles, type Permission } from './adminRbac.js';

export interface AdminUserView {
  id: string;
  email: string;
  name: string;
  status: 'active' | 'suspended' | 'disabled';
  roles: AdminRole[];
  createdAt: string;
  createdBy?: string;
  lastLoginAt?: string;
}

const VALID_ROLES: ReadonlySet<AdminRole> = new Set(ADMIN_ROLES);

function requireDb() {
  if (!isDatabaseConfigured()) {
    throw new Error('Managed administrator identity requires a configured database.');
  }
  return getDb();
}

// ── Pure helpers (unit-testable without a database) ──────────────────────────

/** Keep only recognised roles, de-duplicated and order-stable. */
export function normalizeRoleAssignments(roles: readonly string[]): AdminRole[] {
  const seen = new Set<AdminRole>();
  for (const raw of roles) {
    const role = raw as AdminRole;
    if (VALID_ROLES.has(role)) seen.add(role);
  }
  return ADMIN_ROLES.filter((role) => seen.has(role));
}

/** Effective permissions for a set of roles (delegates to the code matrix). */
export function computeEffectivePermissions(roles: readonly AdminRole[]): Set<Permission> {
  return permissionsForRoles(roles);
}

// ── Permission-resolution cache ──────────────────────────────────────────────
// Short-TTL cache so a role change takes effect quickly (esp. security
// revocations) without a database read on every request.

interface CacheEntry { permissions: ReadonlySet<Permission>; expiresAt: number; }

export class PermissionCache {
  private store = new Map<string, CacheEntry>();
  constructor(
    private readonly ttlMs = 30_000,
    private readonly now: () => number = () => Date.now(),
  ) {}

  async resolve(
    key: string,
    loader: (key: string) => Promise<ReadonlySet<Permission>>,
  ): Promise<ReadonlySet<Permission>> {
    const cached = this.store.get(key);
    const t = this.now();
    if (cached && cached.expiresAt > t) return cached.permissions;
    const permissions = await loader(key);
    this.store.set(key, { permissions, expiresAt: t + this.ttlMs });
    return permissions;
  }

  invalidate(key?: string): void {
    if (key === undefined) this.store.clear();
    else this.store.delete(key);
  }
}

const permissionCache = new PermissionCache();

// ── DB-backed identity operations ────────────────────────────────────────────

export async function createAdminUser(input: {
  email: string;
  name: string;
  createdBy: string;
  passwordHash?: string;
  roles?: readonly string[];
}): Promise<AdminUserView> {
  const db = requireDb();
  const id = 'au_' + crypto.randomBytes(8).toString('hex');
  const email = input.email.trim().toLowerCase();
  const roles = normalizeRoleAssignments(input.roles ?? []);

  await db.transaction(async (tx) => {
    await tx.insert(adminUsers).values({
      id,
      email,
      name: input.name.trim(),
      status: 'active',
      passwordHash: input.passwordHash ?? null,
      createdBy: input.createdBy,
    });
    for (const role of roles) {
      await tx.insert(adminUserRoles).values({
        id: 'aur_' + crypto.randomBytes(8).toString('hex'),
        adminUserId: id,
        role,
        grantedBy: input.createdBy,
      });
    }
  });

  permissionCache.invalidate(id);
  return { id, email, name: input.name.trim(), status: 'active', roles, createdAt: new Date().toISOString(), createdBy: input.createdBy };
}

export async function getAdminRoles(adminUserId: string): Promise<AdminRole[]> {
  const db = requireDb();
  const rows = await db.select({ role: adminUserRoles.role }).from(adminUserRoles)
    .where(eq(adminUserRoles.adminUserId, adminUserId));
  return normalizeRoleAssignments(rows.map((r) => r.role));
}

/** Replace an administrator's role assignments in a single transaction. */
export async function setAdminRoles(
  adminUserId: string,
  roles: readonly string[],
  grantedBy: string,
): Promise<AdminRole[]> {
  const db = requireDb();
  const next = normalizeRoleAssignments(roles);
  await db.transaction(async (tx) => {
    await tx.delete(adminUserRoles).where(eq(adminUserRoles.adminUserId, adminUserId));
    for (const role of next) {
      await tx.insert(adminUserRoles).values({
        id: 'aur_' + crypto.randomBytes(8).toString('hex'),
        adminUserId,
        role,
        grantedBy,
      });
    }
  });
  permissionCache.invalidate(adminUserId);
  return next;
}

export async function listAdminUsers(): Promise<AdminUserView[]> {
  const db = requireDb();
  const users = await db.select().from(adminUsers);
  const assignments = await db.select().from(adminUserRoles);
  const rolesByUser = new Map<string, AdminRole[]>();
  for (const a of assignments) {
    const list = rolesByUser.get(a.adminUserId) ?? [];
    list.push(a.role as AdminRole);
    rolesByUser.set(a.adminUserId, list);
  }
  return users.map((u) => ({
    id: u.id,
    email: u.email,
    name: u.name,
    status: u.status,
    roles: normalizeRoleAssignments(rolesByUser.get(u.id) ?? []),
    createdAt: u.createdAt.toISOString(),
    createdBy: u.createdBy ?? undefined,
    lastLoginAt: u.lastLoginAt ? u.lastLoginAt.toISOString() : undefined,
  }));
}

/**
 * Effective permissions for a managed administrator, cached briefly. Resolves
 * the admin's roles from the database and maps them through the code matrix.
 */
export async function resolveEffectivePermissions(adminUserId: string): Promise<ReadonlySet<Permission>> {
  return permissionCache.resolve(adminUserId, async (id) => computeEffectivePermissions(await getAdminRoles(id)));
}

export function invalidatePermissionCache(adminUserId?: string): void {
  permissionCache.invalidate(adminUserId);
}
