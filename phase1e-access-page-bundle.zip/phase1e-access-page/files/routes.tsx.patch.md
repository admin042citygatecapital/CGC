# routes.tsx — two insertions (do NOT overwrite the file)

## 1. Lazy import — AFTER:
```
const AdminDeveloper       = lazy(() => import('./pages/admin/developer'));
```
Insert:
```ts
const AdminAccess          = lazy(() => import('./pages/admin/access'));
```

## 2. Route entry — AFTER:
```
{ path: '/admin/developer',       element: <AdminOnly><AdminDeveloper /></AdminOnly> },
```
Insert:
```tsx
{ path: '/admin/access',          element: <AdminOnly><AdminAccess /></AdminOnly> },
```
If anchors differ on main, place the lazy const with the other `const Admin* = lazy(...)` lines and the route entry with the other `path: '/admin/...'` entries.
