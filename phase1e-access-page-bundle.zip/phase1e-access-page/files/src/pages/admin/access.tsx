import { Helmet } from '@dr.pogodin/react-helmet';
import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShieldCheck, UserPlus, RefreshCw, AlertCircle, CheckCircle2, X,
  KeyRound, Users, Loader2,
} from 'lucide-react';
import AdminLayout from '@/layouts/AdminLayout';
import { useAdminAuth, authHeaders } from '@/lib/adminAuth';

interface RoleCatalogueEntry { role: string; permissions: string[]; }
interface AccessCatalogue { roles: RoleCatalogueEntry[]; permissions: string[]; }
interface ManagedAdmin {
  id: string; email: string; name: string;
  status: 'active' | 'suspended' | 'disabled';
  roles: string[]; createdAt: string; lastLoginAt?: string;
}
type Toast = { type: 'success' | 'error'; message: string } | null;

const GOLD = 'linear-gradient(135deg, #C9A84C, #F0D080)';

export default function AdminAccess() {
  const { admin, loading: authLoading } = useAdminAuth();
  const navigate = useNavigate();

  const [catalogue, setCatalogue] = useState<AccessCatalogue | null>(null);
  const [admins, setAdmins] = useState<ManagedAdmin[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<Toast>(null);

  // Create form
  const [form, setForm] = useState<{ email: string; name: string; roles: Set<string>; reason: string }>(
    { email: '', name: '', roles: new Set(), reason: '' },
  );
  const [creating, setCreating] = useState(false);

  // Per-admin role editor
  const [editing, setEditing] = useState<{ id: string; roles: Set<string>; reason: string } | null>(null);
  const [savingRoles, setSavingRoles] = useState(false);

  useEffect(() => { if (!authLoading && !admin) navigate('/admin/login'); }, [admin, authLoading, navigate]);

  const notify = useCallback((type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [rolesRes, adminsRes] = await Promise.all([
        fetch('/api/admin/access/roles', { headers: authHeaders() }),
        fetch('/api/admin/access/admins', { headers: authHeaders() }),
      ]);
      if (rolesRes.status === 403 || adminsRes.status === 403) {
        setError('Access management is restricted to the super-administrator.');
        return;
      }
      if (rolesRes.ok) setCatalogue(await rolesRes.json());
      if (adminsRes.ok) {
        const d = await adminsRes.json();
        setAdmins(d.admins ?? []);
      } else if (adminsRes.status === 503) {
        setError('Managed-administrator storage is not configured in this environment yet.');
      }
    } catch {
      setError('Could not reach the access-management service. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  function toggleRole(set: Set<string>, role: string): Set<string> {
    const next = new Set(set);
    if (next.has(role)) next.delete(role); else next.add(role);
    return next;
  }

  async function createAdmin(e: React.FormEvent) {
    e.preventDefault();
    if (!form.email || !form.name) { notify('error', 'Name and email are required.'); return; }
    if (!form.reason.trim()) { notify('error', 'A reason is required for this action.'); return; }
    setCreating(true);
    try {
      const res = await fetch('/api/admin/access/admins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        credentials: 'include',
        body: JSON.stringify({
          email: form.email, name: form.name,
          roles: [...form.roles], reason: form.reason,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        notify('success', `Administrator ${form.email} created.`);
        setForm({ email: '', name: '', roles: new Set(), reason: '' });
        await load();
      } else {
        notify('error', data.error ?? 'Failed to create administrator.');
      }
    } catch {
      notify('error', 'Network error while creating administrator.');
    } finally {
      setCreating(false);
    }
  }

  async function saveRoles() {
    if (!editing) return;
    if (!editing.reason.trim()) { notify('error', 'A reason is required to change roles.'); return; }
    setSavingRoles(true);
    try {
      const res = await fetch(`/api/admin/access/admins/${encodeURIComponent(editing.id)}/roles`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        credentials: 'include',
        body: JSON.stringify({ roles: [...editing.roles], reason: editing.reason }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        notify('success', 'Roles updated.');
        setEditing(null);
        await load();
      } else {
        notify('error', data.error ?? 'Failed to update roles.');
      }
    } catch {
      notify('error', 'Network error while updating roles.');
    } finally {
      setSavingRoles(false);
    }
  }

  const roleNames = catalogue?.roles.map(r => r.role) ?? [];

  return (
    <>
      <Helmet>
        <title>Access Management — CGC Admin</title>
        <meta name="description" content="Manage administrator roles and permissions." />
        <meta name="robots" content="noindex, nofollow" />
        <link rel="canonical" href="https://citygate.capital/admin/access" />
      </Helmet>
      <AdminLayout title="Access Management">
        {/* Toast */}
        <AnimatePresence>
          {toast && (
            <motion.div
              initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}
              className={`fixed top-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl border text-sm ${
                toast.type === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-300'
                  : 'bg-red-500/10 border-red-500/25 text-red-300'
              }`}
              role="status" aria-live="polite"
            >
              {toast.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
              {toast.message}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center justify-between mb-6">
          <p className="text-white/50 text-sm max-w-xl">
            Role-based access control. The super-administrator retains full authority; assign least-privilege
            roles to other administrators. Every change is audited.
          </p>
          <button
            onClick={load}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white/70 text-sm hover:text-white transition-colors"
            aria-label="Refresh"
          >
            <RefreshCw size={14} /> Refresh
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24 text-white/40">
            <Loader2 className="animate-spin" size={20} />
          </div>
        ) : error ? (
          <div className="flex items-start gap-3 p-5 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-sm">
            <AlertCircle size={18} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Left: admins + create */}
            <div className="xl:col-span-2 space-y-6">
              {/* Create admin */}
              <section className="rounded-2xl border border-primary/20 p-6" style={{ background: 'linear-gradient(160deg,#111,#0A0A0A)' }}>
                <h2 className="flex items-center gap-2 text-white font-bold mb-4"><UserPlus size={16} className="text-primary" /> Add administrator</h2>
                <form onSubmit={createAdmin} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="acc-name" className="text-xs text-white/50 uppercase tracking-wide">Full name</label>
                      <input id="acc-name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                        className="px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="acc-email" className="text-xs text-white/50 uppercase tracking-wide">Email</label>
                      <input id="acc-email" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                        className="px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-primary/50" />
                    </div>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <span className="text-xs text-white/50 uppercase tracking-wide">Roles</span>
                    <div className="flex flex-wrap gap-2">
                      {roleNames.map(role => {
                        const active = form.roles.has(role);
                        return (
                          <button type="button" key={role}
                            onClick={() => setForm(f => ({ ...f, roles: toggleRole(f.roles, role) }))}
                            aria-pressed={active}
                            className={`px-3 py-1.5 rounded-lg text-xs border transition-colors ${
                              active ? 'text-black border-transparent' : 'text-white/60 border-white/12 hover:text-white'
                            }`}
                            style={active ? { background: GOLD } : undefined}
                          >
                            {role}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="acc-reason" className="text-xs text-white/50 uppercase tracking-wide">Reason (audited)</label>
                    <input id="acc-reason" value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
                      placeholder="e.g. Onboarding new compliance reviewer"
                      className="px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/25 focus:outline-none focus:border-primary/50" />
                  </div>
                  <button type="submit" disabled={creating}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-black text-sm font-bold disabled:opacity-60"
                    style={{ background: GOLD }}>
                    {creating ? <Loader2 className="animate-spin" size={14} /> : <UserPlus size={14} />}
                    Create administrator
                  </button>
                </form>
              </section>

              {/* Admin list */}
              <section className="rounded-2xl border border-white/8 p-6" style={{ background: 'rgba(10,10,10,0.6)' }}>
                <h2 className="flex items-center gap-2 text-white font-bold mb-4"><Users size={16} className="text-primary" /> Administrators <span className="text-white/30 text-sm font-normal">({admins.length})</span></h2>
                {admins.length === 0 ? (
                  <p className="text-white/40 text-sm py-8 text-center">No managed administrators yet. The super-administrator is the built-in authority.</p>
                ) : (
                  <div className="space-y-3">
                    {admins.map(a => (
                      <div key={a.id} className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/8">
                        <div>
                          <p className="text-white text-sm font-semibold">{a.name} <span className="text-white/30 font-normal">· {a.email}</span></p>
                          <div className="flex flex-wrap gap-1.5 mt-1.5">
                            {a.roles.length === 0
                              ? <span className="text-white/30 text-xs">No roles</span>
                              : a.roles.map(r => <span key={r} className="px-2 py-0.5 rounded-md bg-primary/10 border border-primary/20 text-primary/90 text-[11px]">{r}</span>)}
                          </div>
                        </div>
                        <button
                          onClick={() => setEditing({ id: a.id, roles: new Set(a.roles), reason: '' })}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-white/70 text-xs hover:text-white transition-colors">
                          <KeyRound size={13} /> Edit roles
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>

            {/* Right: role catalogue */}
            <aside className="rounded-2xl border border-white/8 p-6 h-fit" style={{ background: 'rgba(10,10,10,0.6)' }}>
              <h2 className="flex items-center gap-2 text-white font-bold mb-4"><ShieldCheck size={16} className="text-primary" /> Roles &amp; permissions</h2>
              <div className="space-y-3">
                {catalogue?.roles.map(r => (
                  <details key={r.role} className="rounded-xl bg-white/[0.03] border border-white/8 p-3">
                    <summary className="flex items-center justify-between cursor-pointer text-white/80 text-sm">
                      <span>{r.role}</span>
                      <span className="text-white/30 text-xs">{r.permissions.length} perms</span>
                    </summary>
                    <div className="flex flex-wrap gap-1.5 mt-2.5">
                      {r.permissions.map(p => <span key={p} className="px-1.5 py-0.5 rounded bg-white/[0.04] text-white/50 text-[10px]">{p}</span>)}
                    </div>
                  </details>
                ))}
              </div>
            </aside>
          </div>
        )}

        {/* Edit roles drawer */}
        <AnimatePresence>
          {editing && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 flex items-center justify-end bg-black/60 backdrop-blur-sm"
              onClick={() => setEditing(null)}>
              <motion.div initial={{ x: 420 }} animate={{ x: 0 }} exit={{ x: 420 }}
                transition={{ type: 'spring', damping: 28, stiffness: 280 }}
                className="w-full max-w-sm h-full overflow-y-auto border-l border-white/8 p-6 space-y-5"
                style={{ background: 'rgba(10,10,10,0.98)' }}
                onClick={e => e.stopPropagation()}>
                <div className="flex items-center justify-between">
                  <h3 className="text-white font-bold">Edit roles</h3>
                  <button onClick={() => setEditing(null)} className="text-white/30 hover:text-white" aria-label="Close"><X size={16} /></button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {roleNames.map(role => {
                    const active = editing.roles.has(role);
                    return (
                      <button type="button" key={role}
                        onClick={() => setEditing(ed => ed && ({ ...ed, roles: toggleRole(ed.roles, role) }))}
                        aria-pressed={active}
                        className={`px-3 py-1.5 rounded-lg text-xs border transition-colors ${
                          active ? 'text-black border-transparent' : 'text-white/60 border-white/12 hover:text-white'
                        }`}
                        style={active ? { background: GOLD } : undefined}>
                        {role}
                      </button>
                    );
                  })}
                </div>
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="edit-reason" className="text-xs text-white/50 uppercase tracking-wide">Reason (audited)</label>
                  <input id="edit-reason" value={editing.reason}
                    onChange={e => setEditing(ed => ed && ({ ...ed, reason: e.target.value }))}
                    className="px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-primary/50" />
                </div>
                <button onClick={saveRoles} disabled={savingRoles}
                  className="flex items-center justify-center gap-2 w-full py-3 rounded-xl text-black text-sm font-bold disabled:opacity-60"
                  style={{ background: GOLD }}>
                  {savingRoles ? <Loader2 className="animate-spin" size={14} /> : <CheckCircle2 size={14} />}
                  Save roles
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </AdminLayout>
    </>
  );
}
