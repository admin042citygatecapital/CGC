/**
 * auditRedaction.ts — defensive redaction for audit payloads.
 *
 * Audit records must never persist secrets or raw sensitive identifiers, even
 * if a call-site accidentally passes them. This module deep-walks a value and
 * replaces the value of any key that looks sensitive with a placeholder. It is
 * intentionally conservative: it redacts on a key-name allowlist so it never
 * silently drops legitimate operational context.
 *
 * Forbidden per the admin control-plane spec: password, OTP, full session
 * token, Supabase service-role key, SMTP password, OAuth refresh token, private
 * key, CVV, and full PAN.
 */

export const REDACTED = '[REDACTED]';

// Normalised (lowercase, alphanumeric-only) substrings that are safe to match
// anywhere in a key without false positives.
const SENSITIVE_SUBSTRINGS: readonly string[] = [
  'password', 'passwd', 'secret', 'apikey', 'privatekey', 'servicerole',
  'sessiontoken', 'accesstoken', 'refreshtoken', 'oauthtoken', 'bearertoken',
  'authorization', 'smtppass', 'encryptionkey', 'cardnumber', 'cardpan',
  'primaryaccountnumber', 'cvv', 'cvc', 'cardsecuritycode', 'clientsecret',
];

// Normalised keys that must match exactly (short tokens that would false-positive
// as substrings, e.g. 'pan' inside 'company' or 'plan').
const SENSITIVE_EXACT: ReadonlySet<string> = new Set([
  'otp', 'otpcode', 'pan', 'pin', 'token', 'cvv', 'cvc', 'secret',
]);

const MAX_DEPTH = 8;

function normalizeKey(key: string): string {
  return key.toLowerCase().replace(/[^a-z0-9]/g, '');
}

export function isSensitiveKey(key: string): boolean {
  const normalized = normalizeKey(key);
  if (SENSITIVE_EXACT.has(normalized)) return true;
  return SENSITIVE_SUBSTRINGS.some((needle) => normalized.includes(needle));
}

/**
 * Return a deep copy of `value` with the values of sensitive keys replaced by
 * REDACTED. Arrays and plain objects are traversed; other values are returned
 * as-is. Cycles / excessive depth are bounded by MAX_DEPTH.
 */
export function redactSensitive<T>(value: T, depth = 0): T {
  if (value === null || value === undefined) return value;
  if (depth >= MAX_DEPTH) return value;

  if (Array.isArray(value)) {
    return value.map((item) => redactSensitive(item, depth + 1)) as unknown as T;
  }

  if (typeof value === 'object') {
    // Preserve Date and other non-plain objects verbatim.
    if (Object.getPrototypeOf(value) !== Object.prototype) return value;
    const out: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
      out[key] = isSensitiveKey(key) ? REDACTED : redactSensitive(val, depth + 1);
    }
    return out as unknown as T;
  }

  return value;
}
