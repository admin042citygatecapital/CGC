-- 0048_audit_rbac_fields.sql
-- Phase 1 (RBAC foundation): add dedicated structured columns to the audit log
-- so sensitive administration actions record the actor's role, the permission
-- that authorized them, the module/resource acted on, the reason, a correlation
-- request id, the result, and a redacted before/after summary — instead of
-- burying those inside the free-form `details` JSON.
--
-- Additive and idempotent. Existing rows and call-sites remain valid: every new
-- column is nullable and the legacy `details` column is retained.
--
-- NOTE: renumber to follow main's latest migration before committing. The
-- runner applies migrations by sorted filename and tracks them idempotently.

ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS role            TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS permission      TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS module          TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS resource        TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS resource_id     TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS reason          TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS request_id      TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS result          TEXT;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS before_summary  JSONB;
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS after_summary   JSONB;

CREATE INDEX IF NOT EXISTS audit_log_request_id_idx ON audit_log(request_id);
CREATE INDEX IF NOT EXISTS audit_log_module_idx ON audit_log(module);
