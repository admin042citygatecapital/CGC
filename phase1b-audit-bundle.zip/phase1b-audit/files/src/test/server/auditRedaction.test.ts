import { describe, expect, it } from 'vitest';
import { isSensitiveKey, redactSensitive, REDACTED } from '../../server/lib/auditRedaction.js';

describe('audit redaction allowlist', () => {
  it('flags forbidden keys and spares legitimate operational keys', () => {
    for (const key of [
      'password', 'adminPassword', 'smtpPassword', 'sessionToken', 'accessToken',
      'refreshToken', 'otp', 'otpCode', 'cvv', 'pan', 'privateKey', 'apiKey',
      'SUPABASE_SERVICE_ROLE_KEY', 'clientSecret', 'cardNumber', 'token', 'pin',
    ]) {
      expect(isSensitiveKey(key)).toBe(true);
    }
    // Must NOT redact these — false positives would destroy audit value.
    for (const key of [
      'plan', 'company', 'accountPlan', 'amount', 'reason', 'requestId',
      'permission', 'module', 'status', 'panel', 'companyName', 'expanded',
    ]) {
      expect(isSensitiveKey(key)).toBe(false);
    }
  });

  it('deeply redacts sensitive values while preserving structure and safe data', () => {
    const input = {
      reason: 'manual review',
      amount: '100.00',
      accountPlan: 'premium',
      password: 'hunter2',
      nested: {
        otp: '123456',
        card: { pan: '4111111111111111', cvv: '123', last4: '1111' },
      },
      events: [
        { action: 'login', sessionToken: 'abc.def.ghi' },
        { action: 'view', note: 'ok' },
      ],
    };
    const out = redactSensitive(input);

    // Safe data preserved
    expect(out.reason).toBe('manual review');
    expect(out.amount).toBe('100.00');
    expect(out.accountPlan).toBe('premium');
    expect(out.nested.card.last4).toBe('1111');
    expect(out.events[1].note).toBe('ok');

    // Secrets redacted at every depth
    expect(out.password).toBe(REDACTED);
    expect(out.nested.otp).toBe(REDACTED);
    expect(out.nested.card.pan).toBe(REDACTED);
    expect(out.nested.card.cvv).toBe(REDACTED);
    expect(out.events[0].sessionToken).toBe(REDACTED);

    // Original object is not mutated
    expect(input.password).toBe('hunter2');
  });

  it('handles null, primitives, and Date values without throwing', () => {
    expect(redactSensitive(null)).toBeNull();
    expect(redactSensitive('plain')).toBe('plain');
    expect(redactSensitive(42)).toBe(42);
    const d = new Date('2026-01-01T00:00:00.000Z');
    expect(redactSensitive({ when: d }).when).toBe(d);
  });
});
