import { describe, expect, it, vi } from 'vitest';
import type { NextFunction, Request, Response } from 'express';
import type { AdminRole } from '../../server/lib/sessionStore.js';
import {
  allowedRolesForAdminRequest,
  requiredAccessForAdminRequest,
  requireAdminAuthorization,
} from '../../server/lib/adminAuthorizationMiddleware.js';

function request(role: AdminRole | null, path: string, method = 'GET') {
  return {
    path,
    method,
    adminSession: role
      ? {
          adminId: 'admin-test', email: 'admin@example.test', role,
          createdAt: new Date().toISOString(), lastSeenAt: new Date().toISOString(),
          ip: '127.0.0.1', ua: 'test',
        }
      : undefined,
  } as Request;
}

function responseMock() {
  const json = vi.fn();
  const status = vi.fn(() => ({ json }));
  return { response: { status } as unknown as Response, status, json };
}

const NON_SUPER_ROLES: AdminRole[] = [
  'FINANCE_ADMIN', 'COMPLIANCE_ADMIN', 'SECURITY_ADMIN', 'SUPPORT_ADMIN',
  'CONTENT_ADMIN', 'OPERATIONS_ADMIN', 'AUDITOR',
];

describe('admin authorization policy (RBAC)', () => {
  it('allows public authentication routes without a session', () => {
    expect(allowedRolesForAdminRequest('/auth/login', 'POST')).toBeNull();
    const { response, status } = responseMock();
    const next = vi.fn() as NextFunction;
    requireAdminAuthorization(request(null, '/auth/login', 'POST'), response, next);
    expect(next).toHaveBeenCalledOnce();
    expect(status).not.toHaveBeenCalled();
  });

  it('requires authentication on protected routes (401 when no session)', () => {
    const { response, status } = responseMock();
    requireAdminAuthorization(request(null, '/transactions', 'GET'), response, vi.fn() as NextFunction);
    expect(status).toHaveBeenCalledWith(401);
  });

  it('grants SUPER_ADMIN access to every protected route, including unknown ones', () => {
    for (const path of ['/transactions', '/security/roles', '/social/share', '/future-sensitive-tool']) {
      const { response, status } = responseMock();
      const next = vi.fn() as NextFunction;
      requireAdminAuthorization(request('SUPER_ADMIN', path, 'POST'), response, next);
      expect(next).toHaveBeenCalledOnce();
      expect(status).not.toHaveBeenCalled();
    }
  });

  it('fails closed: denies every non-super role on unmapped routes', () => {
    for (const role of NON_SUPER_ROLES) {
      const { response, status } = responseMock();
      const next = vi.fn() as NextFunction;
      requireAdminAuthorization(request(role, '/future-sensitive-tool', 'POST'), response, next);
      expect(next).not.toHaveBeenCalled();
      expect(status).toHaveBeenCalledWith(403);
    }
  });

  it('reserves super-only routes (role/admin management, public publishing, registration approval)', () => {
    const superOnly = ['/users/approve', '/users/reject', '/security/roles', '/social/share', '/access'];
    for (const path of superOnly) {
      for (const role of NON_SUPER_ROLES) {
        const { response, status } = responseMock();
        requireAdminAuthorization(request(role, path, 'POST'), response, vi.fn() as NextFunction);
        expect(status).toHaveBeenCalledWith(403);
      }
      const allowed = responseMock();
      const next = vi.fn() as NextFunction;
      requireAdminAuthorization(request('SUPER_ADMIN', path, 'POST'), allowed.response, next);
      expect(next).toHaveBeenCalledOnce();
    }
  });

  it('scopes finance operations to FINANCE_ADMIN and denies unrelated roles', () => {
    // FINANCE_ADMIN may manage transactions...
    const ok = responseMock();
    const okNext = vi.fn() as NextFunction;
    requireAdminAuthorization(request('FINANCE_ADMIN', '/transactions', 'POST'), ok.response, okNext);
    expect(okNext).toHaveBeenCalledOnce();
    // ...but may NOT change AML/KYC decisions.
    const denied = responseMock();
    requireAdminAuthorization(request('FINANCE_ADMIN', '/kyc/aml', 'POST'), denied.response, vi.fn() as NextFunction);
    expect(denied.status).toHaveBeenCalledWith(403);
    // SUPPORT_ADMIN may not adjust balances.
    const support = responseMock();
    requireAdminAuthorization(request('SUPPORT_ADMIN', '/balance/adjust', 'POST'), support.response, vi.fn() as NextFunction);
    expect(support.status).toHaveBeenCalledWith(403);
  });

  it('scopes KYC decisions to COMPLIANCE_ADMIN and denies finance', () => {
    const ok = responseMock();
    const okNext = vi.fn() as NextFunction;
    requireAdminAuthorization(request('COMPLIANCE_ADMIN', '/kyc/aml', 'POST'), ok.response, okNext);
    expect(okNext).toHaveBeenCalledOnce();

    const denied = responseMock();
    requireAdminAuthorization(request('COMPLIANCE_ADMIN', '/transactions', 'POST'), denied.response, vi.fn() as NextFunction);
    expect(denied.status).toHaveBeenCalledWith(403);
  });

  it('lets AUDITOR read but never write', () => {
    const read = responseMock();
    const readNext = vi.fn() as NextFunction;
    requireAdminAuthorization(request('AUDITOR', '/transactions', 'GET'), read.response, readNext);
    expect(readNext).toHaveBeenCalledOnce();

    const write = responseMock();
    requireAdminAuthorization(request('AUDITOR', '/transactions', 'POST'), write.response, vi.fn() as NextFunction);
    expect(write.status).toHaveBeenCalledWith(403);
  });

  it('maps representative routes to the expected permission', () => {
    expect(requiredAccessForAdminRequest('/transactions', 'POST')).toBe('TRANSACTIONS_MANAGE');
    expect(requiredAccessForAdminRequest('/kyc/aml', 'POST')).toBe('KYC_MANAGE');
    expect(requiredAccessForAdminRequest('/security/roles', 'POST')).toBe('SUPER_ONLY');
    expect(requiredAccessForAdminRequest('/social/share', 'POST')).toBe('SUPER_ONLY');
    expect(requiredAccessForAdminRequest('/future-sensitive-tool', 'POST')).toBeUndefined();
  });
});
