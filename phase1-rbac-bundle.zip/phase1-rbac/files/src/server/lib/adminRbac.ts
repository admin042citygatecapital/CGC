/**
 * adminRbac.ts — Role-Based Access Control catalogue and policy for the
 * administration API.
 *
 * This module is the single, code-authoritative source of truth for:
 *   • the administrator roles,
 *   • the permission catalogue,
 *   • the role → permission matrix,
 *   • the route → required-permission policy.
 *
 * Design invariants (see CGC-ADMIN-RBAC-DESIGN-SPEC.md):
 *   1. Authorization is enforced server-side, per route.
 *   2. Unknown/unmapped routes FAIL CLOSED (deny by default).
 *   3. SUPER_ADMIN is a wildcard authority but is never exempt from auditing.
 *   4. A small set of high-risk routes are reserved to SUPER_ADMIN only.
 *   5. RBAC never enables money movement; financial fail-closed gates are
 *      enforced elsewhere (platformMode.ts) and are unaffected by this module.
 */

import type { AdminRole } from './sessionStore.js';

// ── Roles ─────────────────────────────────────────────────────────────────────

export const ADMIN_ROLES = [
  'SUPER_ADMIN',
  'FINANCE_ADMIN',
  'COMPLIANCE_ADMIN',
  'SECURITY_ADMIN',
  'SUPPORT_ADMIN',
  'CONTENT_ADMIN',
  'OPERATIONS_ADMIN',
  'AUDITOR',
] as const satisfies readonly AdminRole[];

// ── Permission catalogue ────────────────────────────────────────────────────

export const PERMISSIONS = [
  'USERS_READ', 'USERS_MANAGE',
  'ACCOUNTS_READ', 'ACCOUNTS_MANAGE',
  'TRANSACTIONS_READ', 'TRANSACTIONS_MANAGE',
  'TRANSFERS_READ', 'TRANSFERS_MANAGE', 'TRANSFERS_APPROVE',
  'CARDS_READ', 'CARDS_MANAGE',
  'WALLETS_READ', 'WALLETS_MANAGE',
  'TRADING_READ', 'TRADING_MANAGE',
  'RATES_READ', 'RATES_MANAGE',
  'KYC_READ', 'KYC_MANAGE',
  'COMPLIANCE_READ', 'COMPLIANCE_MANAGE',
  'SECURITY_READ', 'SECURITY_MANAGE',
  'SUPPORT_READ', 'SUPPORT_MANAGE',
  'NOTIFICATIONS_MANAGE',
  'EMAIL_READ', 'EMAIL_MANAGE',
  'CMS_READ', 'CMS_MANAGE',
  'MEDIA_READ', 'MEDIA_MANAGE',
  'INTEGRATIONS_READ', 'INTEGRATIONS_MANAGE',
  'FEATURE_FLAGS_READ', 'FEATURE_FLAGS_MANAGE',
  'CONFIG_READ', 'CONFIG_MANAGE',
  'AUDIT_READ',
  'SYSTEM_READ', 'SYSTEM_MANAGE',
  'ADMIN_USERS_MANAGE', 'ROLES_MANAGE',
] as const;

export type Permission = (typeof PERMISSIONS)[number];

/** Sentinel returned for routes reserved exclusively to SUPER_ADMIN. */
export const SUPER_ONLY = 'SUPER_ONLY' as const;
export type RequiredAccess = Permission | typeof SUPER_ONLY;

// ── Role → permission matrix ────────────────────────────────────────────────
// SUPER_ADMIN is intentionally omitted here: it is a wildcard resolved in
// permissionsForRole() to the full catalogue. Every other role lists exactly
// the permissions it holds (least privilege).

const MATRIX: Record<Exclude<AdminRole, 'SUPER_ADMIN'>, readonly Permission[]> = {
  FINANCE_ADMIN: [
    'USERS_READ', 'ACCOUNTS_READ', 'ACCOUNTS_MANAGE',
    'TRANSACTIONS_READ', 'TRANSACTIONS_MANAGE',
    'TRANSFERS_READ', 'TRANSFERS_MANAGE', 'TRANSFERS_APPROVE',
    'CARDS_READ', 'CARDS_MANAGE',
    'WALLETS_READ', 'WALLETS_MANAGE',
    'TRADING_READ', 'TRADING_MANAGE',
    'RATES_READ', 'RATES_MANAGE',
    'INTEGRATIONS_READ', 'FEATURE_FLAGS_READ', 'CONFIG_READ',
    'AUDIT_READ', 'SYSTEM_READ', 'EMAIL_READ',
  ],
  COMPLIANCE_ADMIN: [
    'USERS_READ', 'ACCOUNTS_READ',
    'TRANSACTIONS_READ', 'TRANSFERS_READ',
    'KYC_READ', 'KYC_MANAGE',
    'COMPLIANCE_READ', 'COMPLIANCE_MANAGE',
    'SECURITY_READ',
    'INTEGRATIONS_READ', 'FEATURE_FLAGS_READ', 'CONFIG_READ',
    'AUDIT_READ', 'SYSTEM_READ', 'EMAIL_READ',
  ],
  SECURITY_ADMIN: [
    'USERS_READ', 'ACCOUNTS_READ',
    'CARDS_READ', 'WALLETS_READ',
    'KYC_READ', 'COMPLIANCE_READ',
    'SECURITY_READ', 'SECURITY_MANAGE',
    'NOTIFICATIONS_MANAGE',
    'INTEGRATIONS_READ', 'FEATURE_FLAGS_READ', 'CONFIG_READ',
    'AUDIT_READ', 'SYSTEM_READ', 'EMAIL_READ',
  ],
  SUPPORT_ADMIN: [
    'USERS_READ', 'ACCOUNTS_READ',
    'CARDS_READ', 'KYC_READ',
    'SUPPORT_READ', 'SUPPORT_MANAGE',
    'NOTIFICATIONS_MANAGE',
    'FEATURE_FLAGS_READ', 'CONFIG_READ',
    'SYSTEM_READ', 'EMAIL_READ',
  ],
  CONTENT_ADMIN: [
    'SUPPORT_READ',
    'NOTIFICATIONS_MANAGE',
    'EMAIL_READ', 'EMAIL_MANAGE',
    'CMS_READ', 'CMS_MANAGE',
    'MEDIA_READ', 'MEDIA_MANAGE',
    'FEATURE_FLAGS_READ', 'CONFIG_READ',
    'SYSTEM_READ',
  ],
  OPERATIONS_ADMIN: [
    'USERS_READ', 'ACCOUNTS_READ',
    'TRANSACTIONS_READ', 'TRANSFERS_READ',
    'TRADING_READ', 'RATES_READ',
    'INTEGRATIONS_READ',
    'FEATURE_FLAGS_READ', 'FEATURE_FLAGS_MANAGE',
    'CONFIG_READ',
    'AUDIT_READ', 'SYSTEM_READ', 'SYSTEM_MANAGE',
    'EMAIL_READ',
  ],
  AUDITOR: [
    'USERS_READ', 'ACCOUNTS_READ',
    'TRANSACTIONS_READ', 'TRANSFERS_READ',
    'CARDS_READ', 'WALLETS_READ',
    'TRADING_READ', 'RATES_READ',
    'KYC_READ', 'COMPLIANCE_READ', 'SECURITY_READ',
    'SUPPORT_READ', 'EMAIL_READ',
    'CMS_READ', 'MEDIA_READ',
    'INTEGRATIONS_READ', 'FEATURE_FLAGS_READ', 'CONFIG_READ',
    'AUDIT_READ', 'SYSTEM_READ',
  ],
};

const ALL_PERMISSIONS: ReadonlySet<Permission> = new Set(PERMISSIONS);

const ROLE_PERMISSIONS: Record<AdminRole, ReadonlySet<Permission>> = {
  SUPER_ADMIN: ALL_PERMISSIONS,
  FINANCE_ADMIN: new Set(MATRIX.FINANCE_ADMIN),
  COMPLIANCE_ADMIN: new Set(MATRIX.COMPLIANCE_ADMIN),
  SECURITY_ADMIN: new Set(MATRIX.SECURITY_ADMIN),
  SUPPORT_ADMIN: new Set(MATRIX.SUPPORT_ADMIN),
  CONTENT_ADMIN: new Set(MATRIX.CONTENT_ADMIN),
  OPERATIONS_ADMIN: new Set(MATRIX.OPERATIONS_ADMIN),
  AUDITOR: new Set(MATRIX.AUDITOR),
};

/** Effective permissions for a single role (SUPER_ADMIN → full catalogue). */
export function permissionsForRole(role: AdminRole): ReadonlySet<Permission> {
  return ROLE_PERMISSIONS[role] ?? new Set<Permission>();
}

/** Effective permissions for a set of roles (union). */
export function permissionsForRoles(roles: readonly AdminRole[]): Set<Permission> {
  const out = new Set<Permission>();
  for (const role of roles) {
    for (const p of permissionsForRole(role)) out.add(p);
  }
  return out;
}

export function roleHasPermission(role: AdminRole, permission: Permission): boolean {
  return role === 'SUPER_ADMIN' || permissionsForRole(role).has(permission);
}

// ── Route → required-permission policy ──────────────────────────────────────
// Paths here are relative to the /api/admin mount (e.g. '/transactions'),
// matching how requireAdminAuthorization receives req.path.
//
// Each entry maps a route prefix to the permission required for READ
// (GET/HEAD) and WRITE (POST/PUT/PATCH/DELETE). `SUPER_ONLY` reserves the
// route to SUPER_ADMIN. Longest-prefix wins, so specific rules (e.g.
// 'users/approve') override general ones (e.g. 'users').

interface RouteRule {
  prefix: string;               // no leading slash, e.g. 'users' or 'users/approve'
  read: RequiredAccess;
  write: RequiredAccess;
}

// Order does not matter; matching uses longest prefix.
const ROUTE_RULES: readonly RouteRule[] = [
  // High-risk / reserved to super admin (preserve historical safety posture)
  { prefix: 'users/approve', read: SUPER_ONLY, write: SUPER_ONLY },
  { prefix: 'users/reject', read: SUPER_ONLY, write: SUPER_ONLY },
  { prefix: 'security/roles', read: SUPER_ONLY, write: SUPER_ONLY },
  { prefix: 'security/admins', read: SUPER_ONLY, write: SUPER_ONLY },
  { prefix: 'access', read: SUPER_ONLY, write: SUPER_ONLY },           // admin-user/role management (future)
  { prefix: 'social/share', read: SUPER_ONLY, write: SUPER_ONLY },      // public publishing reserved to super
  { prefix: 'social/publish', read: SUPER_ONLY, write: SUPER_ONLY },

  // Users / customers
  { prefix: 'users', read: 'USERS_READ', write: 'USERS_MANAGE' },
  { prefix: 'contacts', read: 'USERS_READ', write: 'USERS_MANAGE' },

  // Accounts
  { prefix: 'customer-accounts', read: 'ACCOUNTS_READ', write: 'ACCOUNTS_MANAGE' },
  { prefix: 'customer-relationships', read: 'ACCOUNTS_READ', write: 'ACCOUNTS_MANAGE' },

  // Transactions & transfers
  { prefix: 'transactions/approve', read: 'TRANSACTIONS_READ', write: 'TRANSFERS_APPROVE' },
  { prefix: 'transactions/reject', read: 'TRANSACTIONS_READ', write: 'TRANSFERS_APPROVE' },
  { prefix: 'transactions', read: 'TRANSACTIONS_READ', write: 'TRANSACTIONS_MANAGE' },
  { prefix: 'transfers/approve', read: 'TRANSFERS_READ', write: 'TRANSFERS_APPROVE' },
  { prefix: 'transfers/reject', read: 'TRANSFERS_READ', write: 'TRANSFERS_APPROVE' },
  { prefix: 'transfers', read: 'TRANSFERS_READ', write: 'TRANSFERS_MANAGE' },
  { prefix: 'financial-sandbox', read: 'TRANSFERS_READ', write: 'TRANSFERS_MANAGE' },
  { prefix: 'balance/adjust', read: 'TRANSACTIONS_READ', write: 'TRANSACTIONS_MANAGE' },
  { prefix: 'balance', read: 'TRANSACTIONS_READ', write: 'TRANSACTIONS_MANAGE' },
  { prefix: 'reconciliation', read: 'TRANSACTIONS_READ', write: 'TRANSACTIONS_MANAGE' },
  { prefix: 'disputes', read: 'SUPPORT_READ', write: 'SUPPORT_MANAGE' },

  // Cards / wallets / trading / rates
  { prefix: 'cards', read: 'CARDS_READ', write: 'CARDS_MANAGE' },
  { prefix: 'wallets', read: 'WALLETS_READ', write: 'WALLETS_MANAGE' },
  { prefix: 'trading', read: 'TRADING_READ', write: 'TRADING_MANAGE' },
  { prefix: 'rates', read: 'RATES_READ', write: 'RATES_MANAGE' },

  // KYC / compliance / onboarding / legal entity
  { prefix: 'kyc', read: 'KYC_READ', write: 'KYC_MANAGE' },
  { prefix: 'onboarding', read: 'KYC_READ', write: 'KYC_MANAGE' },
  { prefix: 'legal-entity', read: 'KYC_READ', write: 'KYC_MANAGE' },
  { prefix: 'compliance', read: 'COMPLIANCE_READ', write: 'COMPLIANCE_MANAGE' },

  // Security
  { prefix: 'security', read: 'SECURITY_READ', write: 'SECURITY_MANAGE' },

  // Support / tickets / chat
  { prefix: 'support', read: 'SUPPORT_READ', write: 'SUPPORT_MANAGE' },
  { prefix: 'tickets', read: 'SUPPORT_READ', write: 'SUPPORT_MANAGE' },
  { prefix: 'smartsupp', read: 'SUPPORT_READ', write: 'SUPPORT_MANAGE' },
  { prefix: 'chatbot', read: 'SUPPORT_READ', write: 'SUPPORT_MANAGE' },

  // Notifications
  { prefix: 'notifications', read: 'SYSTEM_READ', write: 'NOTIFICATIONS_MANAGE' },

  // Email
  { prefix: 'email', read: 'EMAIL_READ', write: 'EMAIL_MANAGE' },
  { prefix: 'smtp', read: 'EMAIL_READ', write: 'EMAIL_MANAGE' },
  { prefix: 'newsletter', read: 'EMAIL_READ', write: 'EMAIL_MANAGE' },
  { prefix: 'zoho', read: 'EMAIL_READ', write: 'EMAIL_MANAGE' },

  // CMS / website / media
  { prefix: 'cms', read: 'CMS_READ', write: 'CMS_MANAGE' },
  { prefix: 'website', read: 'CMS_READ', write: 'CMS_MANAGE' },
  { prefix: 'social', read: 'CMS_READ', write: 'CMS_MANAGE' },
  { prefix: 'links', read: 'CMS_READ', write: 'CMS_MANAGE' },
  { prefix: 'media', read: 'MEDIA_READ', write: 'MEDIA_MANAGE' },

  // Integrations / features / config
  { prefix: 'integrations', read: 'INTEGRATIONS_READ', write: 'INTEGRATIONS_MANAGE' },
  { prefix: 'features', read: 'FEATURE_FLAGS_READ', write: 'FEATURE_FLAGS_MANAGE' },
  { prefix: 'config', read: 'CONFIG_READ', write: 'CONFIG_MANAGE' },
  { prefix: 'settings', read: 'CONFIG_READ', write: 'CONFIG_MANAGE' },

  // Audit / reports
  { prefix: 'audit', read: 'AUDIT_READ', write: 'AUDIT_READ' },
  { prefix: 'reports', read: 'AUDIT_READ', write: 'AUDIT_READ' },
  { prefix: 'stats', read: 'SYSTEM_READ', write: 'SYSTEM_READ' },

  // System / diagnostics / operations
  { prefix: 'health', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
  { prefix: 'readiness', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
  { prefix: 'env-report', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
  { prefix: 'developer', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
  { prefix: 'documentation', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
  { prefix: 'search', read: 'SYSTEM_READ', write: 'SYSTEM_READ' },
  { prefix: 'operations', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
  { prefix: 'provider-sandbox', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
  { prefix: 'sponsor-readiness', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
  { prefix: 'assurance-exercises', read: 'SYSTEM_READ', write: 'SYSTEM_MANAGE' },
];

function normalizePath(path: string): string {
  if (!path || path === '/') return '/';
  const normalized = path.startsWith('/') ? path : `/${path}`;
  return normalized.length > 1 && normalized.endsWith('/') ? normalized.slice(0, -1) : normalized;
}

function isWrite(method: string): boolean {
  const m = method.toUpperCase();
  return m === 'POST' || m === 'PUT' || m === 'PATCH' || m === 'DELETE';
}

/** Returns true when `normalizedPath` is or is under `/prefix`. */
function matchesPrefix(normalizedPath: string, prefix: string): boolean {
  const p = `/${prefix}`;
  return normalizedPath === p || normalizedPath.startsWith(`${p}/`);
}

/**
 * The access required to reach a protected admin route, or `SUPER_ONLY`, or
 * `undefined` when no rule matches (caller MUST fail closed — deny by default).
 */
export function requiredAccessForAdminRequest(
  path: string,
  method: string,
): RequiredAccess | undefined {
  const normalizedPath = normalizePath(path);
  let best: RouteRule | undefined;
  for (const rule of ROUTE_RULES) {
    if (matchesPrefix(normalizedPath, rule.prefix)) {
      if (!best || rule.prefix.length > best.prefix.length) best = rule;
    }
  }
  if (!best) return undefined;
  return isWrite(method) ? best.write : best.read;
}
