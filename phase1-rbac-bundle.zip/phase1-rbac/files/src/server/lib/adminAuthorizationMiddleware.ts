/**
 * Central authorization policy for the administration API.
 *
 * Authentication answers "who is this?"; this middleware answers "may this
 * administrator perform this operation?". Authorization is permission-based
 * and enforced server-side per route (see adminRbac.ts and
 * CGC-ADMIN-RBAC-DESIGN-SPEC.md).
 *
 * Invariants:
 *   • SUPER_ADMIN is a wildcard authority (but is still audited downstream).
 *   • A small set of high-risk routes is reserved to SUPER_ADMIN only.
 *   • Unknown/new admin routes FAIL CLOSED (deny by default).
 *   • A role reaches a route only when its effective permissions (adminRbac
 *     matrix) include the route's required permission.
 */
import type { NextFunction, Request, Response } from 'express';
import type { AdminRole } from './sessionStore.js';
import {
  ADMIN_ROLES,
  SUPER_ONLY,
  permissionsForRole,
  requiredAccessForAdminRequest,
} from './adminRbac.js';

// Re-exported so existing call-sites/tests can import the route→permission
// policy from the middleware module.
export { requiredAccessForAdminRequest } from './adminRbac.js';
export type { Permission, RequiredAccess } from './adminRbac.js';

const PUBLIC_ADMIN_PATHS = new Set([
  '/auth/login',
  '/auth/password-reset',
  '/auth/password-reset/confirm',
  '/auth/otp/verify',
  '/auth/unlock',
  '/auth/diag',
  '/auth/verify',
  '/zoho/oauth/callback',
  '/sponsor-readiness/external-review',
]);

function normalizePath(path: string): string {
  if (!path || path === '/') return '/';
  const normalized = path.startsWith('/') ? path : `/${path}`;
  return normalized.length > 1 && normalized.endsWith('/') ? normalized.slice(0, -1) : normalized;
}

/**
 * Back-compat helper. Returns the set of roles permitted to reach a route, or
 * `null` for public routes. Derived from the RBAC matrix:
 *   • public route            → null
 *   • unmapped route          → [] (deny by default; only SUPER_ADMIN via the
 *                                   wildcard in requireAdminAuthorization)
 *   • SUPER_ONLY route        → ['SUPER_ADMIN']
 *   • permission-mapped route → every role whose permissions include it
 *
 * Note: SUPER_ADMIN is always implicitly authorized in
 * requireAdminAuthorization regardless of this list.
 */
export function allowedRolesForAdminRequest(path: string, method: string): readonly AdminRole[] | null {
  const normalizedPath = normalizePath(path);
  if (PUBLIC_ADMIN_PATHS.has(normalizedPath)) return null;

  const required = requiredAccessForAdminRequest(normalizedPath, method);
  if (required === undefined) return [];          // deny by default (super still passes)
  if (required === SUPER_ONLY) return ['SUPER_ADMIN'];

  return ADMIN_ROLES.filter(role => permissionsForRole(role).has(required));
}

export function requireAdminAuthorization(req: Request, res: Response, next: NextFunction): void {
  const normalizedPath = normalizePath(req.path);
  if (PUBLIC_ADMIN_PATHS.has(normalizedPath)) {
    next();
    return;
  }

  const session = req.adminSession;
  if (!session) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  // SUPER_ADMIN wildcard (still flows through CSRF + audit downstream).
  if (session.role === 'SUPER_ADMIN') {
    next();
    return;
  }

  const required = requiredAccessForAdminRequest(normalizedPath, req.method);

  // Deny by default: unmapped routes and super-only routes are unreachable by
  // any non-super role.
  if (required === undefined || required === SUPER_ONLY) {
    res.status(403).json({
      error: 'This administration is restricted to the super-administrator.',
      code: 'SUPER_ADMIN_REQUIRED',
    });
    return;
  }

  if (permissionsForRole(session.role).has(required)) {
    next();
    return;
  }

  res.status(403).json({
    error: 'You do not have permission to perform this administration.',
    code: 'PERMISSION_REQUIRED',
    permission: required,
  });
}
