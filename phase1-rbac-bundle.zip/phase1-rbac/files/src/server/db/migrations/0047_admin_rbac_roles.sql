-- 0047_admin_rbac_roles.sql
-- Phase 1 (RBAC foundation): extend the admin_role enum with the operational
-- roles introduced by the role-based access control model. Additive and
-- idempotent — no existing value is removed or renamed, so historical audit
-- rows remain valid. SUPER_ADMIN remains the wildcard authority; these roles
-- are least-privilege operational roles enforced server-side (see adminRbac.ts).
--
-- NOTE: ALTER TYPE ... ADD VALUE is supported inside a transaction on
-- PostgreSQL 12+. The new values are only *added* here (never used in this same
-- migration), which avoids the "unsafe use of new enum value" restriction.

ALTER TYPE admin_role ADD VALUE IF NOT EXISTS 'CONTENT_ADMIN';
ALTER TYPE admin_role ADD VALUE IF NOT EXISTS 'OPERATIONS_ADMIN';
ALTER TYPE admin_role ADD VALUE IF NOT EXISTS 'AUDITOR';
