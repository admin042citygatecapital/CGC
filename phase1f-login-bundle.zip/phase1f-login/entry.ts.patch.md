# entry.ts — one more insertion (on top of increment 4's /access routes)

## Import — AFTER:
```
import admin_access_admins_id_roles_post from "./api/admin/access/admins/[id]/roles/POST";
```
Insert:
```ts
import admin_access_admins_id_password_post from "./api/admin/access/admins/[id]/password/POST";
```

## Registration — AFTER:
```
app.post("/api/admin/access/admins/:id/roles", admin_access_admins_id_roles_post);
```
Insert:
```ts
app.post("/api/admin/access/admins/:id/password", admin_access_admins_id_password_post);
```
