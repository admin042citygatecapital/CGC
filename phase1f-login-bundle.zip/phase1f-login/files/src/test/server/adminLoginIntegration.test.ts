import { describe, expect, it, vi } from 'vitest';
import type { NextFunction, Request, Response } from 'express';
import type { AdminRole } from '../../server/lib/sessionStore.js';
import { resolveAdminForLogin, pickPrimaryRole } from '../../server/lib/adminCredentials.js';
import { requireAdminAuthorization } from '../../server/lib/adminAuthorizationMiddleware.js';

describe('login resolution', () => {
  it('resolves the env SUPER_ADMIN break-glass account first', async () => {
    const admin = await resolveAdminForLogin('admin@citygate.capital');
    expect(admin).toBeDefined();
    expect(admin?.isSuper).toBe(true);
    expect(admin?.primaryRole).toBe('SUPER_ADMIN');
    expect(admin?.roles).toEqual(['SUPER_ADMIN']);
  });

  it('returns undefined for an unknown email (no enumeration, storage absent)', async () => {
    const admin = await resolveAdminForLogin('nobody@example.com');
    expect(admin).toBeUndefined();
  });

  it('picks the highest-priority role as the session primary', () => {
    expect(pickPrimaryRole(['AUDITOR', 'FINANCE_ADMIN'])).toBe('FINANCE_ADMIN');
    expect(pickPrimaryRole(['SUPPORT_ADMIN', 'COMPLIANCE_ADMIN'])).toBe('COMPLIANCE_ADMIN');
    expect(pickPrimaryRole(['AUDITOR'])).toBe('AUDITOR');
  });
});

function req(roles: AdminRole[], path: string, method = 'POST') {
  return {
    path, method,
    adminSession: {
      adminId: 'au_1', email: 'mgr@citygate.capital', role: roles[0], roles,
      createdAt: '', lastSeenAt: '', ip: '127.0.0.1', ua: 'test',
    },
  } as Request;
}
function resMock() {
  const json = vi.fn();
  const status = vi.fn(() => ({ json }));
  return { response: { status } as unknown as Response, status };
}

describe('multi-role session enforcement', () => {
  it('unions permissions across a managed admin\'s roles', () => {
    const roles: AdminRole[] = ['COMPLIANCE_ADMIN', 'FINANCE_ADMIN'];
    // Compliance grants KYC_MANAGE...
    const kyc = resMock(); const kycNext = vi.fn() as NextFunction;
    requireAdminAuthorization(req(roles, '/kyc/aml'), kyc.response, kycNext);
    expect(kycNext).toHaveBeenCalledOnce();
    // ...finance grants TRANSACTIONS_MANAGE.
    const tx = resMock(); const txNext = vi.fn() as NextFunction;
    requireAdminAuthorization(req(roles, '/transactions'), tx.response, txNext);
    expect(txNext).toHaveBeenCalledOnce();
  });

  it('still denies a permission no assigned role holds', () => {
    const support = resMock();
    requireAdminAuthorization(req(['SUPPORT_ADMIN'], '/transactions'), support.response, vi.fn() as NextFunction);
    expect(support.status).toHaveBeenCalledWith(403);
  });

  it('treats a role set containing SUPER_ADMIN as wildcard', () => {
    const r = resMock(); const next = vi.fn() as NextFunction;
    requireAdminAuthorization(req(['SUPER_ADMIN'], '/security/roles'), r.response, next);
    expect(next).toHaveBeenCalledOnce();
  });

  it('remains backward-compatible with single-role sessions (no roles array)', () => {
    const single = {
      path: '/transactions', method: 'POST',
      adminSession: { adminId: 'a', email: 'x', role: 'FINANCE_ADMIN' as AdminRole, createdAt: '', lastSeenAt: '', ip: '', ua: '' },
    } as Request;
    const r = resMock(); const next = vi.fn() as NextFunction;
    requireAdminAuthorization(single, r.response, next);
    expect(next).toHaveBeenCalledOnce();
  });
});
