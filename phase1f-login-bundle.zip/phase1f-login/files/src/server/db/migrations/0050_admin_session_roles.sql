-- 0050_admin_session_roles.sql
-- Phase 1 (RBAC login integration): record the full assigned role set on the
-- admin session so managed administrators can hold multiple roles. Additive
-- and idempotent; existing sessions (and the env SUPER_ADMIN) work unchanged —
-- when `roles` is NULL the enforcement layer falls back to the single `role`.
--
-- NOTE: renumber to follow main's latest migration before committing.

ALTER TABLE admin_sessions ADD COLUMN IF NOT EXISTS roles JSONB;
