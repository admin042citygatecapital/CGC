/**
 * Secure administrator credential store.
 *
 * The password hash is loaded from the ADMIN_PASSWORD_HASH environment secret.
 * Hashes are resolved at request time via env — never at module-load time.
 *
 * New hashes use Argon2id. Legacy bcrypt/PBKDF2 hashes remain verifiable so
 * existing installations can migrate without an emergency password reset.
 */

import { getSecret } from '#runtime/secrets';
import {
  hashPassword as hashSecurePassword,
  verifyPassword as verifySecurePassword,
} from './passwordHash.js';
import type { AdminRole } from './sessionStore.js';
import { ADMIN_ROLES } from './adminRbac.js';
import { findManagedAdminByEmail } from './adminIdentityStore.js';

export interface AdminRecord {
  id:           string;
  email:        string;
  name:         string;
  role:         string;
  avatar:       string;
  passwordHash: string;
}

const ADMIN_STATIC: Omit<AdminRecord, 'passwordHash'>[] = [
  {
    id:     'admin_001',
    email:  'admin@citygate.capital',
    name:   'Super Admin',
    role:   'superadmin',
    avatar: 'SA',
  },
];

function isSupportedHash(value: string): boolean {
  return value.startsWith('$argon2') || value.startsWith('$2a$') ||
    value.startsWith('$2b$') || value.startsWith('$2y$') || value.startsWith('100000:');
}

/** Resolve hash from env secrets at request time (V2 takes precedence). */
function resolveHash(): string {
  const v2 = String(getSecret('ADMIN_PASSWORD_HASH_V2') ?? process.env.ADMIN_PASSWORD_HASH_V2 ?? '');
  if (isSupportedHash(v2)) return v2;
  const primary = String(getSecret('ADMIN_PASSWORD_HASH') ?? process.env.ADMIN_PASSWORD_HASH ?? '');
  if (isSupportedHash(primary)) return primary;
  return '';
}

export function getAdminUsers(): AdminRecord[] {
  const secretHash = resolveHash();
  return ADMIN_STATIC.map(u => ({
    ...u,
    passwordHash: secretHash,
  }));
}

export function findAdminByEmail(email: string): AdminRecord | undefined {
  return getAdminUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
}

/**
 * Unified administrator resolution for the login flow.
 *
 * The env-bootstrap SUPER_ADMIN is resolved first and unchanged (break-glass).
 * If no env admin matches, a managed administrator (admin_users) is resolved,
 * but only when it is genuinely able to sign in: status 'active', a password
 * hash set, and at least one role assigned. Anything else resolves to
 * undefined so the caller returns generic invalid-credentials (no enumeration).
 */
export interface LoginAdmin {
  id: string;
  email: string;
  name: string;
  avatar: string;
  passwordHash: string;
  roles: AdminRole[];
  primaryRole: AdminRole;
  isSuper: boolean;
  managedId?: string;
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'AD';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

/** Highest-priority assigned role by the canonical ADMIN_ROLES order. */
export function pickPrimaryRole(roles: readonly AdminRole[]): AdminRole {
  const set = new Set(roles);
  for (const role of ADMIN_ROLES) if (set.has(role)) return role;
  return 'AUDITOR';
}

export async function resolveAdminForLogin(email: string): Promise<LoginAdmin | undefined> {
  // 1) Env-bootstrap SUPER_ADMIN — resolved first, behaviour unchanged.
  const envAdmin = findAdminByEmail(email);
  if (envAdmin) {
    return {
      id: envAdmin.id,
      email: envAdmin.email,
      name: envAdmin.name,
      avatar: envAdmin.avatar,
      passwordHash: envAdmin.passwordHash,
      roles: ['SUPER_ADMIN'],
      primaryRole: 'SUPER_ADMIN',
      isSuper: true,
    };
  }

  // 2) Managed administrator — only if it can actually sign in.
  let managed = null;
  try {
    managed = await findManagedAdminByEmail(email);
  } catch {
    // Managed-admin storage not configured → no managed admins exist.
    managed = null;
  }
  if (!managed) return undefined;
  if (managed.status !== 'active') return undefined;
  if (!managed.passwordHash) return undefined;
  if (managed.roles.length === 0) return undefined;

  return {
    id: managed.id,
    email: managed.email,
    name: managed.name,
    avatar: initials(managed.name),
    passwordHash: managed.passwordHash,
    roles: managed.roles,
    primaryRole: pickPrimaryRole(managed.roles),
    isSuper: false,
    managedId: managed.id,
  };
}

/** Create new administrator hashes using the platform's Argon2id policy. */
export async function hashPassword(password: string): Promise<string> {
  return hashSecurePassword(password);
}

/** Verify current Argon2id hashes and supported legacy bcrypt/PBKDF2 hashes. */
export async function verifyPassword(plain: string, stored: string): Promise<boolean> {
  return (await verifySecurePassword(plain, stored)).ok;
}
