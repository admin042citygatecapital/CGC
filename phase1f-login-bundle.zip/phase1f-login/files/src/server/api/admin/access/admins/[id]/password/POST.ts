/**
 * POST /api/admin/access/admins/:id/password
 *
 * Sets (or replaces) a managed administrator's sign-in password. The password
 * is provided by the super-administrator and hashed server-side with the
 * platform's Argon2id policy — the raw value is never stored or logged.
 * Reserved to SUPER_ADMIN by the central authorization policy (`access` →
 * SUPER_ONLY).
 *
 * Body: { password, reason }
 */
import type { Request, Response } from 'express';
import { hashPassword } from '../../../../../../lib/adminCredentials.js';
import { setAdminPassword } from '../../../../../../lib/adminIdentityStore.js';
import { validatePassword, sanitizeString, safeObject } from '../../../../../../lib/inputValidator.js';
import { appendAuditEntry } from '../../../../../../lib/auditLog.js';

export default async function handler(req: Request, res: Response) {
  const session = req.adminSession;
  if (!session) return res.status(401).json({ error: 'Authentication required' });

  const id = String(req.params.id ?? '').trim();
  if (!id) return res.status(400).json({ error: 'Administrator ID required' });

  const body = safeObject(req.body) ?? {};
  const password = typeof body.password === 'string' ? body.password : '';
  const reason = sanitizeString(body.reason, 500);

  const pw = validatePassword(password);
  if (!pw.ok) return res.status(400).json({ error: pw.reason ?? 'Password does not meet policy.' });
  if (!reason) return res.status(400).json({ error: 'A reason is required for this administration action.' });

  try {
    const hash = await hashPassword(password);
    const updated = await setAdminPassword(id, hash);
    if (!updated) return res.status(404).json({ error: 'Unknown administrator.' });

    await appendAuditEntry({
      adminId: session.adminId,
      adminEmail: session.email,
      action: 'admin_user_password_set',
      module: 'access',
      resource: 'admin_user',
      resourceId: id,
      role: session.role,
      permission: 'ADMIN_USERS_MANAGE',
      reason,
      result: 'success',
      // NB: never include the password or its hash in the audit record.
    }).catch((auditError) => {
      console.error('[access] structured audit failed for admin_user_password_set', {
        errorType: auditError instanceof Error ? auditError.name : 'UnknownError',
      });
    });
    return res.json({ ok: true, id });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes('requires a configured database')) {
      return res.status(503).json({ error: 'Managed administrator storage is not configured.' });
    }
    console.error('[access] set password failed', { errorType: error instanceof Error ? error.name : 'UnknownError' });
    return res.status(500).json({ error: 'Failed to set administrator password.' });
  }
}
